You can use this child theme to modify the parent theme to fit your needs. Make sure you DON'T remove the parent theme from your themes folder. For licensing and copyright information please check the file readme.txt of the parent theme.

********************************************************************************
Read more about child themes here: http://codex.wordpress.org/Child_Themes
********************************************************************************