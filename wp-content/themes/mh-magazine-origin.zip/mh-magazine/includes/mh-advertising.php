<?php

/***** Include Content Ad on Posts *****/

if (!function_exists('mh_magazine_content_ad')) {
	function mh_magazine_content_ad($content) {
		if (is_singular('post') && is_main_query()) {
			global $post;
			$mh_magazine_options = mh_magazine_theme_options();
			$ad_position = 1;
			$paragraphs = explode("<p", $content);
			$counter = 0;
			foreach($paragraphs as $paragraph) {
				if ($counter == 0) {
					$content = $paragraph;
				}
				if ($counter > 0) {
					$content .= '<p' . $paragraph;
				}
				if ($counter == $ad_position) {
           			if (!get_post_meta($post->ID, 'mh-no-ad', true)) {
			   			if (get_post_meta($post->ID, 'mh-alt-ad', true)) {
				   			$adcode = '<div class="mh-content-ad">' . do_shortcode(get_post_meta($post->ID, 'mh-alt-ad', true)) . '</div>' . "\n";
				   		} else {
							$adcode = !empty($mh_magazine_options['content_ad']) ? '<div class="mh-content-ad">' . do_shortcode($mh_magazine_options['content_ad']) . '</div>' . "\n" : '';
						}
						$content .= $adcode;
					}
				}
				$counter++;
			}
			return $content;
		} else {
			return $content;
		}
	}
}
add_filter('the_content', 'mh_magazine_content_ad');

/***** Include Ads on Archives *****/

if (!function_exists('mh_magazine_loop_ads')) {
	function mh_magazine_loop_ads($post) {
		global $wp_query;
		$mh_magazine_options = mh_magazine_theme_options();
		$adcode = empty($mh_magazine_options['loop_ad']) ? '' : '<div class="mh-loop-ad">' . do_shortcode($mh_magazine_options['loop_ad']) . '</div>' . "\n";
		$adcount = empty($mh_magazine_options['loop_ad_no']) ? 3 : $mh_magazine_options['loop_ad_no'];
		if (in_the_loop() && is_archive() || in_the_loop() && is_home()) {
			if ($wp_query->post != $post)
			return;
			if ($wp_query->current_post == 0)
			return;
			if ($wp_query->current_post % $adcount == 0) {
				echo $adcode;
			}
		}
	}
}
add_action('the_post', 'mh_magazine_loop_ads');

?>